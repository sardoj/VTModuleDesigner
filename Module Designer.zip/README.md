VTModuleDesigner
================

Module Designer for Vtiger 6

You can set your own fields and variables. To do this modify these files:
- /vlayouts/layout/Settings/ModuleDesigner/Custom.tpl
- /vlayouts/layout/Settings/ModuleDesigner/resources/CustomScript.js
- /modules/ModuleDesigner/CustomManifestStructure.php

You can also create plugins to handle your variables, in the directory /modules/ModuleDesigner/plugins